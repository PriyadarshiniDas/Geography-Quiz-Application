package edu.uga.cs.countryquiz2;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

/**
 * Class representation of results screen
 */
public class ResultActivity extends AppCompatActivity {
    TextView tvResult;
    Button btHome;
    Button btScoreboard;

    /**
     * Initialize buttons to change screens and assign listeners
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        // get quiz result from QuestionActivity
        Intent intent = getIntent();
        int quizResult = intent.getIntExtra("QUIZ_RESULT", 0);
        tvResult = (TextView) findViewById(R.id.textView5);
        tvResult.setText(quizResult + "");

        btHome = (Button) findViewById(R.id.button2);
        // event handler to go to home page
        btHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                v.getContext().startActivity(intent);
            }
        });

        btScoreboard = (Button) findViewById(R.id.button);
        // event handler to go to scoreboard
        btScoreboard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), ScoreboardActivity.class);
                v.getContext().startActivity(intent);
            }
        });

    }
}
