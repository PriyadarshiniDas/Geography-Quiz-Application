package edu.uga.cs.countryquiz2;

import android.content.Context;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class dbHelper extends SQLiteOpenHelper {

    private static String TAG = "DataBaseHelper"; // Tag just for the LogCat window

    //destination path (location) of our database on device
    //private static final String DB_PATH = "/data/data/com.example.project4R1/databases/";
    private static  String DB_PATH = "";
    private static  String DB_NAME = "GeographyQuiz.db";

    private static final int DB_VERSION = 1;
    private final Context mContext;
    private SQLiteDatabase mDataBase;


    public dbHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
        if(android.os.Build.VERSION.SDK_INT >= 17){
            DB_PATH = context.getApplicationInfo().dataDir + "/databases/";
        }
        else
        {
            DB_PATH = "/data/data/" + context.getPackageName() + "/databases/";
        }
        this.mContext=context;
    }

    public void createDataBase() throws IOException
    {



        //SQLiteDatabase.deleteDatabase();
        //If the database does not exist, copy it from the assets.
        //mContext.deleteDatabase(DB_NAME);
        boolean mDataBaseExist = checkDataBase();
        if(!mDataBaseExist)
        {
            this.getReadableDatabase();
            this.close();
            try
            {
                //Copy the database from assests
                copyDataBase();
                Log.e(TAG, "createDatabase database created");
                TestAdapter mDbHelper =  new TestAdapter(mContext);
                mDbHelper.updateNullValue();

            }
            catch (IOException mIOException)
            {
                throw new Error("ErrorCopyingDataBase");
            }
        }
    }
    //Check that the database exists here: /data/data/your package/databases/Da Name
    private boolean checkDataBase()
    {
        File dbFile = new File(DB_PATH + DB_NAME);
        //Log.v("dbFile", dbFile + "   "+ dbFile.exists());
        return dbFile.exists();
    }


    //Copy the database from assets
    private void copyDataBase() throws IOException
    {
        InputStream mInput = mContext.getAssets().open(DB_NAME);
        String outFileName = DB_PATH + DB_NAME;
        OutputStream mOutput = new FileOutputStream(outFileName);
        byte[] mBuffer = new byte[1024];
        int mLength;
        while ((mLength = mInput.read(mBuffer))>0)
        {
            mOutput.write(mBuffer, 0, mLength);
        }
        mOutput.flush();
        mOutput.close();
        mInput.close();
    }


    //Open the database, so we can query it
    public boolean openDataBase() throws SQLException
    {
        String mPath = DB_PATH + DB_NAME;
        //Log.v("mPath", mPath);
        mDataBase = SQLiteDatabase.openDatabase(mPath, null, SQLiteDatabase.CREATE_IF_NECESSARY);
        //mDataBase = SQLiteDatabase.openDatabase(mPath, null, SQLiteDatabase.NO_LOCALIZED_COLLATORS);
        return mDataBase != null;
    }

    @Override
    public synchronized void close()
    {
        if(mDataBase != null)
            mDataBase.close();
        super.close();
    }


    public void insertQuize(String q1,String a1,String q2,String a2,String q3,String a3,String q4,String a4,String q5,String a5,String q6,String
            a6){

        //String query = "INSERT INTO Quizzes (Date, Score, Answered) VALUES ('" + date + "', " + result + ", NULL)";
        String query = "INSERT INTO quizes (q1,a1,q2,a2,q3,a3,q4,a4,q5,a5,q6,a6) VALUES ('"+q1+"','"+a1+"','"+q2+"','"+a2+"'" +
                ",'"+q3+"','"+a3+"','"+q4+"','"+a4+"','"+q5+"','"+a5+"','"+q6+"','"+a6+"')";
        mDataBase.execSQL(query);
    }




    @Override
    public void onCreate(SQLiteDatabase db) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
