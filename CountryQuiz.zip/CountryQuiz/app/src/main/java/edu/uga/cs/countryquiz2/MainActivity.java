package edu.uga.cs.countryquiz2;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button btPlay;
    Button btScoreboard;
    private static TestAdapter mDbHelper;

    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        btPlay = findViewById(R.id.btPlay);
        btPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(getApplicationContext(), QuestionActivity.class);
                v.getContext().startActivity(intent);

            }
        });

        btScoreboard = (Button) findViewById(R.id.btScores);
        btScoreboard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), ScoreboardActivity.class);
                v.getContext().startActivity(intent);
            }
        });
    }


}

