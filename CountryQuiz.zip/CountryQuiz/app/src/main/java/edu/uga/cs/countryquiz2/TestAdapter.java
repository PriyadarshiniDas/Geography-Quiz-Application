package edu.uga.cs.countryquiz2;

import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import java.io.IOException;
import java.util.ArrayList;

public class TestAdapter {
    protected static final String TAG = "DataAdapter";

    private final Context mContext;
    private SQLiteDatabase mDb;
    private dbHelper mDbHelper;

    public TestAdapter(Context context)
    {
        this.mContext = context;
        mDbHelper = new dbHelper(mContext);
    }

    public TestAdapter createDatabase() throws SQLException
    {
        try
        {
            mDbHelper.createDataBase();
        }
        catch (IOException mIOException)
        {
            Log.e(TAG, mIOException.toString() + "  UnableToCreateDatabase");
            throw new Error("UnableToCreateDatabase");
        }
        return this;
    }

    public TestAdapter open() throws SQLException
    {
        try
        {
            mDbHelper.openDataBase();
            mDbHelper.close();
            mDb = mDbHelper.getReadableDatabase();
        }
        catch (SQLException mSQLException)
        {
            Log.e(TAG, "open >>"+ mSQLException.toString());
            throw mSQLException;
        }
        return this;
    }

    public void close()
    {
        mDbHelper.close();
    }

    public Cursor getTestData()
    {
        try
        {
            String sql ="SELECT * FROM quizes";

            Cursor mCur = mDb.rawQuery(sql, null);
            if (mCur!=null)
            {
                mCur.moveToNext();
            }
            return mCur;
        }
        catch (SQLException mSQLException)
        {
            Log.e(TAG, "getTestData >>"+ mSQLException.toString());
            throw mSQLException;
        }
    }

    public void updateNullValue(){

       // String query = "INSERT INTO quizes (q1,a1,q2,a2,q3,a3,q4,a4,q5,a5,q6,a6) VALUES ('" + date + "', " + result + ", NULL)";
        String query = "UPDATE country_neighbour SET Neighbour = 'None' WHERE Neighbour IS NULL OR LENGTH(Neighbour)=0";
        mDb.execSQL(query);
    }



    public void insertQuize(String q1,String a1,String q2,String a2,String q3,String a3,String q4,String a4,String q5,String a5,String q6,String
            a6){

        //String query = "INSERT INTO Quizzes (Date, Score, Answered) VALUES ('" + date + "', " + result + ", NULL)";
        String query = "INSERT INTO quizes (q1,a1,q2,a2,q3,a3,q4,a4,q5,a5,q6,a6) VALUES ('"+q1+"','"+a1+"','"+q2+"','"+a2+"'" +
                ",'"+q3+"','"+a3+"','"+q4+"','"+a4+"','"+q5+"','"+a5+"','"+q6+"','"+a6+"')";
        mDb.execSQL(query);
    }


    public void insertQuize(String[][] newQuiz, String date){


        Log.d("newQuiz()", "Executing Insert Query");
        //String query = "INSERT INTO Quizzes (Date, Score, Answered) VALUES ('" + date + "', " + result + ", NULL)";
        String query = "INSERT INTO quizes (q1,a1,q2,a2,q3,a3,q4,a4,q5,a5,q6,a6,date) VALUES " +
                "('"+newQuiz[0][0]+"','"+newQuiz[0][1]+"','"+newQuiz[1][0]+"','"+newQuiz[1][1]+"'" +
                ",'"+newQuiz[2][0]+"','"+newQuiz[2][1]+"','"+newQuiz[3][0]+"','"+newQuiz[3][1]+"','"+
                newQuiz[4][0]+"','"+newQuiz[4][1]+"','"+newQuiz[5][0]+"','"+newQuiz[5][1]+"','"+date+"' )";

        mDb.execSQL(query);
    }

    public int getQuizId(){

        String query = "SELECT * FROM quizes ";

        Cursor cursor;
        cursor = mDb.rawQuery(query, null);
        return cursor.getCount();

    }

    public void insertQuizResult(String date, int result){


        //int sid = getQuizId()-1;
        Log.e(TAG, "insertQuizResult >>"+result);
        //Log.e(TAG, "insertQuizResult >>"+sid);
        String query = "INSERT INTO score (total_score,number_of_correct_answer,number_of_wrong_answer,date) VALUES (" + result + "," + result + "," + (6-result) +",'" + date + "')";
        mDb.execSQL(query);
    }



    // Select 6 random country with their answer
    public String[][] getQuiz() {

        String[][] quiz = new String[6][4];
        String query = "SELECT DISTINCT COUNTRY, CONTINENT FROM country_continent ORDER BY RANDOM() LIMIT 3";

        Cursor cursor;

        try {
            Log.d("getQuiz()", "Executing Query");
            cursor = mDb.rawQuery(query, null);
            int row = 0;

            // traverse results of query and add them to the quiz array
            while (cursor.moveToNext()) {

                for (int i = 0; i < 2; i++) {
                    quiz[row][i] = cursor.getString(i);
                }
                row++;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }


        // get 2 other random answors
        //query = "SELECT DISTINCT CONTINENT FROM country_continent ORDER BY RANDOM() LIMIT 6";

        Log.d("getQuiz(0,1)", quiz[0][1]);

        int row = 0;
        while(row < 3) {
            query = "SELECT DISTINCT CONTINENT FROM country_continent WHERE CONTINENT != '" + quiz[row][1] + "'  ORDER BY RANDOM() LIMIT 2";
            try {
                Log.d("getQuiz()", "Executing Query");
                cursor = mDb.rawQuery(query, null);

                int coumnNumber = 2;
                // traverse results of query and add them to the quiz array
                while (cursor.moveToNext()) {

                    quiz[row][coumnNumber] = cursor.getString(0);
                    Log.d("getQuiz(cursor)", cursor.getString(0));
                    if (coumnNumber == 2) {
                        coumnNumber = 3;
                    } else {
                        coumnNumber = 2;
                        row++;
                    }

                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }


        // select from country_neighbour 3 country
         query = "SELECT DISTINCT Country, Neighbour FROM country_neighbour ORDER BY RANDOM() LIMIT 3";

        Cursor cursor2;
        try {
            Log.d("getQuiz()", "Executing Query");
            cursor2 = mDb.rawQuery(query, null);
             row = 0;

            // traverse results of query and add them to the quiz array
            while (cursor2.moveToNext()) {

                for (int i = 0; i < 2; i++) {
                    quiz[row+3][i] = cursor2.getString(i);
                }
                row++;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        // get 2 other random answers country_neighbour DISTINCT a
       // query = "SELECT DISTINCT Neighbour FROM country_neighbour ORDER BY RANDOM() LIMIT 6";
        row = 3;
        while(row < 6) {
            query = "SELECT DISTINCT Neighbour FROM country_neighbour WHERE Country != '" + quiz[row][0] + "' AND Neighbour != '" + quiz[row][1] + "'  ORDER BY RANDOM() LIMIT 2";
            try {
                Log.d("getQuiz()", "Executing Query");
                cursor2 = mDb.rawQuery(query, null);

                int coumnNumber = 2;
                // traverse results of query and add them to the quiz array
                while (cursor2.moveToNext()) {

                    quiz[row][coumnNumber] = cursor2.getString(0);

                    if (coumnNumber == 2) {
                        coumnNumber = 3;
                    } else {
                        coumnNumber = 2;
                        row++;
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return quiz;
    }



    public ArrayList<String> getQuizResults(){

        ArrayList<String> results = new ArrayList<>();
        String query = "SELECT total_score, date  FROM score";
        Cursor cursor = mDb.rawQuery(query, null);

        // header for listview
        //results.add(String.format("Score","correct","wrong","Date"));
        results.add(String.format("%-14s%-66s","Score" , "Date and Time"));

        // traverse query results and add them to ArrayList
        while(cursor.moveToNext()){

            String[] result = new String[3];
            for(int i = 0; i < 2; i++) {
                if (cursor.isNull(i)) {
                    result[i] = "";
                }
                else{
                result[i] = cursor.getString(i);
                Log.d("getQuizResults()", cursor.getString(i));
                }
            }
            //results.add(String.format( result[0]));
            //results.add(String.format( result[0],result[1]));
            results.add(String.format("%-18s%-46s", result[0].trim(), result[1].trim() + "/6"));
        }
        return results;
    }


}
