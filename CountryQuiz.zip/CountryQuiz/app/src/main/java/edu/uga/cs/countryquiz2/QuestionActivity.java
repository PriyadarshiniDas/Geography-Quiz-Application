package edu.uga.cs.countryquiz2;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.constraint.ConstraintLayout;
import android.support.constraint.ConstraintSet;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.TextView;

import java.util.Date;

/**
 * Class representation of quiz questions
 */
public class QuestionActivity extends AppCompatActivity {

    private QuestionsPagerAdapter mQuestionsPagerAdapter;
    private ActionBar mActionBar;
    private ViewPager mViewPager;
    private static Context mContext;
    private static Questions questions;
    private static TestAdapter mDbHelper;
    String[][] quiz;
    protected static final String TAG = "DatabaseTest";
    /**
     * Initialize Quiz Questions and asynchronously retrieve questions
     * from the Questions table
     * @param savedInstanceState Saved continent before onPause()
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question);


        mDbHelper =  new TestAdapter(this);
        NewQuizTask task = new NewQuizTask();

        task.execute();
        quiz = task.doInBackground();
        questions = new Questions(quiz);





        //    Allow user to swipe between questions
        mQuestionsPagerAdapter = new QuestionsPagerAdapter(getSupportFragmentManager(), 3);
        mViewPager = (ViewPager) findViewById(R.id.pager);
        mViewPager.setAdapter(mQuestionsPagerAdapter);

        // set page title
        mActionBar = getSupportActionBar();
        mActionBar.setTitle(mQuestionsPagerAdapter.getPageTitle(0));

        mContext = this;

        //Listener for swipe event
        mViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int i, float v, int i1) {
            }

            @Override
            public void onPageSelected(int position) {
                mActionBar.setTitle(mQuestionsPagerAdapter.getPageTitle(position));
            }

            @Override
            public void onPageScrollStateChanged(int i) {
            }
        });

    }

    /**
     *  Fragment adapter for controlling view pager
     */
    public class QuestionsPagerAdapter extends FragmentPagerAdapter {
        private final int mSize;

        public QuestionsPagerAdapter(FragmentManager fm, int size) {
            super(fm);
            this.mSize = size;
        }

        @Override
        public Fragment getItem(int position) {
            return QuestionFragment.newInstance(position + 1);
        }

        @Override
        public int getCount() {
            return mSize;
        }

        /**
         * Set title of page to question number
         * @param position question number
         * @return String to be set as title
         */
        @Override
        public CharSequence getPageTitle(int position) {
            int questionNum = position + 1;
            return String.valueOf("Question " + questionNum);
        }
    }

    /**
     * Fragment representing a question
     */
    public static class QuestionFragment extends Fragment {

        private static final String ARG_SECTION_NUMBER = "section_number";
        private int mQuestionNum;
        private TextView mTextView;
        private TextView mTextView2;
        private ConstraintLayout questionLayout;
        private RadioButton rb1;
        private RadioButton rb2;
        private RadioButton rb3;
        private RadioButton rb4;
        private RadioButton rb5;
        private RadioButton rb6;
        String continent;
        String[] options;
        String neighbour;
        String[] options2;

        /**
         * Create an instance of question fragment
         * @param questionNumber question nummber
         * @return question fragment
         */
        public static QuestionFragment newInstance(int questionNumber) {
            QuestionFragment fragment = new QuestionFragment();
            Bundle args = new Bundle();
            args.putInt(ARG_SECTION_NUMBER, questionNumber);
            fragment.setArguments(args);
            return fragment;
        }

        /**
         * Create new Question Fragment
         * @param savedInstanceState retrieve insatnce continent before onPause()
         */
        @Override
        public void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);

            if (getArguments() != null) {
                mQuestionNum = getArguments().getInt(ARG_SECTION_NUMBER);
            } else {
                mQuestionNum = -1;
            }
        }

        /**
         * Initialize UI elements
         * @param inflater
         * @param container
         * @param savedInstanceState
         * @return
         */
        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
            View rootView = inflater.inflate(R.layout.fragment_question, container, false);
            questionLayout = (ConstraintLayout) rootView.findViewById(R.id.constraintLayout);

            // Question A
            mTextView = (TextView) rootView.findViewById(R.id.textView2);
            rb1 = (RadioButton) rootView.findViewById(R.id.radioButton);
            rb2 = (RadioButton) rootView.findViewById(R.id.radioButton2);
            rb3 = (RadioButton) rootView.findViewById(R.id.radioButton3);
            continent = questions.getState(mQuestionNum - 1);
            options = questions.getOptions(mQuestionNum - 1);


            // Question B
            mTextView2 = (TextView) rootView.findViewById(R.id.textView3);
            rb4 = (RadioButton) rootView.findViewById(R.id.radioButton4);
            rb5 = (RadioButton) rootView.findViewById(R.id.radioButton5);
            rb6 = (RadioButton) rootView.findViewById(R.id.radioButton6);
            neighbour = questions.getState(mQuestionNum+3 - 1);
            options2 = questions.getOptions(mQuestionNum+3 - 1);

            return rootView;
        }

        /**
         * Provide UI elements with content and set button and radiobuttons listeners
         * @param savedInstanceState
         */
        @Override
        public void onActivityCreated(Bundle savedInstanceState) {
            super.onActivityCreated(savedInstanceState);


            if (QuestionActivity.class.isInstance(getActivity())) {

                mTextView.setText("A) Name the continent on which "+ continent + " is located ? ");

                rb1.setText(options[0]);
                rb2.setText(options[1]);
                rb3.setText(options[2]);

                rb1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                        questions.setUserAnswer(mQuestionNum - 1, rb1.getText().toString());
                        Log.d("RADIO_BUTTON_1", "Question" + mQuestionNum + ": User answer:" + questions.getUserAnswer(mQuestionNum - 1));

                    }
                });
                rb2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                        questions.setUserAnswer(mQuestionNum - 1, rb2.getText().toString());
                        Log.d("RADIO_BUTTON_2", "Question" + mQuestionNum + ": User answer:" + questions.getUserAnswer(mQuestionNum - 1));

                    }
                });
                rb3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                        questions.setUserAnswer(mQuestionNum - 1, rb3.getText().toString());
                        Log.d("RADIO_BUTTON_3", "Question" + mQuestionNum + ": User answer:" + questions.getUserAnswer(mQuestionNum - 1));

                    }
                });


                mTextView2.setText("B) What is the neighbour country for "+ neighbour + " ? ");

                rb4.setText(options2[0]);
                rb5.setText(options2[1]);
                rb6.setText(options2[2]);

                rb4.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                        questions.setUserAnswer(mQuestionNum+3 - 1, rb4.getText().toString());
                        Log.d("RADIO_BUTTON_1", "Question" + mQuestionNum + ": User answer:" + questions.getUserAnswer(mQuestionNum+3 - 1));

                    }
                });
                rb5.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                        questions.setUserAnswer(mQuestionNum+3 - 1, rb5.getText().toString());
                        Log.d("RADIO_BUTTON_2", "Question" + mQuestionNum + ": User answer:" + questions.getUserAnswer(mQuestionNum+3 - 1));

                    }
                });
                rb6.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                        questions.setUserAnswer(mQuestionNum+3 - 1, rb6.getText().toString());
                        Log.d("RADIO_BUTTON_3", "Question" + mQuestionNum+3 + ": User answer:" + questions.getUserAnswer(mQuestionNum+3 - 1));

                    }
                });

                // programatically create button to submit quiz, only shown
                // at the last question
                if (mQuestionNum == 3) {

                    Button btEndQuiz = new Button(mContext);
                    btEndQuiz.setText("End quiz and see result");
                    btEndQuiz.setId(R.id.end_quizz_button_id);
                    questionLayout.addView(btEndQuiz);
                    ConstraintSet constraintSet = new ConstraintSet();
                    constraintSet.clone(questionLayout);
                    constraintSet.connect(btEndQuiz.getId(), ConstraintSet.BOTTOM, questionLayout.getId(), ConstraintSet.BOTTOM, 64);
                    constraintSet.connect(btEndQuiz.getId(), ConstraintSet.START, questionLayout.getId(), ConstraintSet.START);
                    constraintSet.connect(btEndQuiz.getId(), ConstraintSet.END, questionLayout.getId(), ConstraintSet.END);
                    constraintSet.applyTo(questionLayout);

                    /**
                     * OnClick event handler for submit button
                     * Saves answers and score to Quizzes table, and
                     * go to ResultActivity
                     */
                    btEndQuiz.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            int result = questions.getResult();
                            Log.d("QUIZ_RESULT", "quiz result = " + result);


                            mDbHelper.open();
                            mDbHelper.insertQuizResult(new Date().toString(), result);
                            mDbHelper.close();
                            Intent intent = new Intent(mContext, ResultActivity.class);
                            intent.putExtra("QUIZ_RESULT", result);
                            v.getContext().startActivity(intent);
                        }
                    });
                }
            }
        }

    }



    /**
     * Asynchronous for retrieving questions
     */
    public class NewQuizTask extends AsyncTask<Void, Void, String[][]> {

        @Override

        protected String[][] doInBackground(Void... params) {
            mDbHelper.createDatabase();
            dbHelper myDB;
            myDB = new dbHelper(QuestionActivity.this);
            //myDB.createDataBase();

            TestAdapter mDbHelper = new TestAdapter(QuestionActivity.this);

            mDbHelper.open();
            // select random 6 question for new quiz
            String[][] newQuiz = mDbHelper.getQuiz();
            mDbHelper.close();
            for (int i = 0 ; i < 6; i ++){
                    Log.e(TAG, "QuizQuestion(" + i + ") >> " + newQuiz[i][0] +"  " + newQuiz[i][1]
                            +"  " + newQuiz[i][2]
                            +"  " + newQuiz[i][3]);
                }


            return newQuiz;
        }
    }

}
