package edu.uga.cs.countryquiz2;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.io.IOException;
import java.util.ArrayList;

/**
 * Class representation of Scoreboard screen
 */
public class ScoreboardActivity extends AppCompatActivity {

    Button btHome;
    ListView listView;
    ArrayAdapter adapter;

    /**
     * Assign listener to return to home screen and populate
     * ListView with user scores from Quizzes table
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scoreboard);

        RetrieveAllScoresTask task = new RetrieveAllScoresTask();

        //ArrayList<String> list=new ArrayList<>();
        ArrayList<String> list = task.doInBackground();

        Log.d("RetrieveAllScoresTask()",list.get(0));
        Log.d("RetrieveAllScoresTask()", String.valueOf(list.size()));


        // populate listView
        listView = findViewById(R.id.resultsList);
        adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, list);
        listView.setAdapter(adapter);

        btHome = findViewById(R.id.button5);
        // listener to return to home screen
        btHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                v.getContext().startActivity(intent);
            }
        });
    }



    /**
     * asynchronous task to retrieve user Scores from Quizzes table
     */
    public class RetrieveAllScoresTask extends AsyncTask<Void, Void, ArrayList<String>>{

        //QuestionDBHelper myDBHelper;

        //dbHelper myDB = new dbHelper(ScoreboardActivity.this);


        TestAdapter mDbHelper = new TestAdapter(ScoreboardActivity.this);


        /**
         * get results from Quizzes table
         * @param voids
         * @return ArrayList of user's scores
         */
        @Override
        protected ArrayList<String> doInBackground(Void... voids) {
            mDbHelper.createDatabase();
                mDbHelper.open();
                // select random 6 question for new quiz
                ArrayList<String> quizzesScore  = mDbHelper.getQuizResults();
                mDbHelper.close();
                return quizzesScore;
        }
    }
}
