package edu.uga.cs.countryquiz2;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class SplashScreen extends AppCompatActivity {

    private static TestAdapter mDbHelper;
    TextView textView ;
    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        mDbHelper =  new TestAdapter(this);
        SplashScreen.RetrieveDateTask task = new SplashScreen.RetrieveDateTask();

        task.execute();
        task.doInBackground();



        textView = (TextView) findViewById(R.id.textView);
        textView.setVisibility(View.GONE);

        button = (Button) findViewById(R.id.button);
        button.setVisibility(View.GONE);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(SplashScreen.this, MainActivity.class);
                startActivity(i);
                finish();

            }
        });

        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {


                textView.setVisibility(View.VISIBLE);
                button.setVisibility(View.VISIBLE);

            }
        }, 3000);



    }

    /**
     * asynchronous task to retrieve user Scores from Quizzes table
     */
    public class RetrieveDateTask extends AsyncTask<Void, Void, Void> {

        dbHelper myDB = new dbHelper(SplashScreen.this);


        TestAdapter mDbHelper = new TestAdapter(SplashScreen.this);


        /**
         * get results from Quizzes table
         * @param voids
         * @return ArrayList of user's scores
         */
        @Override
        protected Void doInBackground(Void... voids) {
            mDbHelper.createDatabase();
            mDbHelper.open();

            mDbHelper.close();

            // return quizzesScore;
            return null;
        }
//
//        @Override
//        protected Void doInBackground(Void... voids) {
//            return null;
//        }
    }




}
