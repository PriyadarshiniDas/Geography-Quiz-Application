package edu.uga.cs.countryquiz2;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class Questions implements Serializable {


    private String[][] questionsArray;
    private String[] userAnswers = new String[6];

    public Questions() {

    }
    public Questions(String[][] quizQuestions) {
        questionsArray = quizQuestions;
    }

    public String getState(int questionNum) {
        return questionsArray[questionNum][0];
    }

    public String[] getOptions(int questionNum) {
        String[] options = new String[3];
        options[0] = questionsArray[questionNum][1];
        options[1] = questionsArray[questionNum][2];
        options[2] = questionsArray[questionNum][3];

        ArrayList<String> list = new ArrayList<>(Arrays.asList(options));
        Collections.shuffle(list);
        list.toArray(options);
        return options;
    }

    public String getCapital(int questionNum) {
        return questionsArray[questionNum][1];
    }

    public String getUserAnswer(int questionNum) {
        return userAnswers[questionNum];
    }

    public void setUserAnswer(int questionNum, String userAnswer) {
        userAnswers[questionNum] = userAnswer;
    }

    public int getResult() {
        int result = 0;

        for (int i = 0; i < questionsArray.length; i++) {
            if((questionsArray[i][1])==(userAnswers[i])) {
                result++;
            }
            else
                result=result;
        }
        return result;
    }
}
